public class InterfaceGraphique implements Affichage{

  public void afficherPlateau(Plateau plateau){



  }

  public void afficherMessage(String str){



  }

}
